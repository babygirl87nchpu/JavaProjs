package edu.vt.cs5044;

import edu.vt.cs5044.tetris.Tetris5044;
import javafx.application.Application;

@SuppressWarnings("javadoc")
public class Launcher
{
    public static void main(String[] args)
    {
        Application.launch(Tetris5044.class);
    }
} 
